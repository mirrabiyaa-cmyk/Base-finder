package dev.hamzah.basefinder;

import net.minecraft.client.gui.GuiGraphics;
import net.minecraft.client.gui.components.Button;
import net.minecraft.client.gui.screens.Screen;
import net.minecraft.network.chat.Component;

public class BaseFinderScreen extends Screen {
    private int left, top, panelWidth = 236;

    public BaseFinderScreen() { super(Component.literal("BASEFINDER")); }

    @Override
    protected void init() {
        left = (width - panelWidth) / 2;
        top = (height - 220) / 2;
        int y = top + 58;
        addToggle("Storage ESP", () -> BaseFinderClient.chests, v -> BaseFinderClient.chests = v, y); y += 25;
        addToggle("Hopper ESP", () -> BaseFinderClient.hoppers, v -> BaseFinderClient.hoppers = v, y); y += 25;
        addToggle("Dispenser / Dropper", () -> BaseFinderClient.dispensers, v -> BaseFinderClient.dispensers = v, y); y += 25;
        addToggle("Shulker ESP", () -> BaseFinderClient.shulkers, v -> BaseFinderClient.shulkers = v, y); y += 25;
        addToggle("Crafter ESP", () -> BaseFinderClient.crafters, v -> BaseFinderClient.crafters = v, y); y += 25;
        addToggle("Tracers", () -> BaseFinderClient.tracers, v -> BaseFinderClient.tracers = v, y);
        addRenderableWidget(Button.builder(Component.literal("Range: " + BaseFinderClient.range + " blocks"), b -> {
            BaseFinderClient.range = BaseFinderClient.range >= 64 ? 16 : BaseFinderClient.range + 16;
            b.setMessage(Component.literal("Range: " + BaseFinderClient.range + " blocks"));
        }).bounds(left + 18, top + 220 - 38, panelWidth - 36, 20).build());
    }

    private void addToggle(String label, java.util.function.Supplier<Boolean> getter, java.util.function.Consumer<Boolean> setter, int y) {
        addRenderableWidget(Button.builder(toggleText(label, getter.get()), b -> {
            setter.accept(!getter.get());
            b.setMessage(toggleText(label, getter.get()));
        }).bounds(left + 18, y, panelWidth - 36, 20).build());
    }

    private Component toggleText(String label, boolean on) {
        return Component.literal(label + "  " + (on ? "§aON" : "§cOFF"));
    }

    @Override
    public void render(GuiGraphics g, int mouseX, int mouseY, float delta) {
        renderBackground(g, mouseX, mouseY, delta);
        g.fill(left - 2, top - 2, left + panelWidth + 2, top + 248, 0xFF6B43C8);
        g.fill(left, top, left + panelWidth, top + 244, 0xF5101118);
        g.fill(left, top, left + panelWidth, top + 42, 0xFF171923);
        g.drawString(font, "BASEFINDER", left + 18, top + 12, 0xFFF5F5FF, false);
        g.drawString(font, "RENDER MODULES  •  " + (BaseFinderClient.enabled ? "§aACTIVE" : "§cDISABLED"), left + 18, top + 29, 0xFFB9B8D0, false);
        super.render(g, mouseX, mouseY, delta);
        g.drawCenteredString(font, "Y = master toggle  |  Right Shift = menu", width / 2, top + 252, 0xFFB9B8D0);
    }

    @Override public boolean isPauseScreen() { return false; }
}
