package dev.hamzah.basefinder;

import com.mojang.blaze3d.vertex.PoseStack;
import com.mojang.blaze3d.vertex.VertexConsumer;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.core.BlockPos;
import net.minecraft.world.level.block.Block;
import net.minecraft.world.level.block.Blocks;
import net.minecraft.world.level.block.CrafterBlock;
import net.minecraft.world.level.block.DispenserBlock;
import net.minecraft.world.level.block.HopperBlock;
import net.minecraft.world.level.block.ShulkerBoxBlock;
import net.minecraft.world.level.block.ChestBlock;
import net.minecraft.world.level.block.state.BlockState;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import org.lwjgl.glfw.GLFW;

import java.util.ArrayList;
import java.util.List;

public class BaseFinderClient implements ClientModInitializer {
    private static KeyMapping toggleKey;
    private static KeyMapping menuKey;
    private static final List<Target> TARGETS = new ArrayList<>();
    private static int scanCooldown = 0;

    static boolean enabled = false;
    static boolean chests = true;
    static boolean hoppers = true;
    static boolean dispensers = true;
    static boolean shulkers = true;
    static boolean crafters = true;
    static boolean tracers = true;
    static int range = 32;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.basefinder.toggle", GLFW.GLFW_KEY_Y, "key.category.basefinder"));
        menuKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.basefinder.menu", GLFW.GLFW_KEY_RIGHT_SHIFT, "key.category.basefinder"));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) enabled = !enabled;
            while (menuKey.consumeClick()) client.setScreen(new BaseFinderScreen());
            if (!enabled || client.level == null || client.player == null) {
                TARGETS.clear();
                return;
            }
            if (scanCooldown-- <= 0) {
                scanCooldown = 15;
                scan(client);
            }
        });

        WorldRenderEvents.AFTER_ENTITIES.register(context -> {
            Minecraft client = Minecraft.getInstance();
            if (!enabled || client.level == null || client.player == null || context.consumers() == null) return;
            Vec3 camera = context.worldState().cameraRenderState.pos;
            PoseStack matrices = context.matrices();
            matrices.pushPose();
            matrices.translate(-camera.x, -camera.y, -camera.z);
            VertexConsumer lines = context.consumers().getBuffer(RenderType.lines());
            Vec3 eye = client.player.getEyePosition();
            for (Target target : TARGETS) {
                AABB box = new AABB(target.pos).inflate(0.005);
                float r = target.r, g = target.g, b = target.b;
                LevelRenderer.renderLineBox(matrices, lines, box, r, g, b, 1.0f);
                if (tracers) {
                    Vec3 end = Vec3.atCenterOf(target.pos);
                    drawLine(matrices, lines, eye, end, r, g, b);
                }
            }
            matrices.popPose();
        });
    }

    private static void scan(Minecraft client) {
        TARGETS.clear();
        BlockPos origin = client.player.blockPosition();
        int r = range;
        int vertical = Math.min(16, r);
        BlockPos.MutableBlockPos pos = new BlockPos.MutableBlockPos();
        for (int x = origin.getX() - r; x <= origin.getX() + r; x++) {
            for (int y = Math.max(client.level.getMinY(), origin.getY() - vertical); y <= Math.min(client.level.getMaxY(), origin.getY() + vertical); y++) {
                for (int z = origin.getZ() - r; z <= origin.getZ() + r; z++) {
                    if (client.player.distanceToSqr(x + 0.5, y + 0.5, z + 0.5) > (double) r * r) continue;
                    pos.set(x, y, z);
                    if (!client.level.hasChunkAt(pos)) continue;
                    BlockState state = client.level.getBlockState(pos);
                    Target target = classify(state, pos);
                    if (target != null) TARGETS.add(target);
                }
            }
        }
    }

    private static Target classify(BlockState state, BlockPos pos) {
        Block block = state.getBlock();
        if (chests && block instanceof ChestBlock) return new Target(pos.immutable(), 0.65f, 0.8f, 1.0f);
        if (hoppers && block instanceof HopperBlock) return new Target(pos.immutable(), 1.0f, 0.65f, 0.2f);
        if (dispensers && (block instanceof DispenserBlock || block == Blocks.DROPPER)) return new Target(pos.immutable(), 1.0f, 0.3f, 0.3f);
        if (shulkers && block instanceof ShulkerBoxBlock) return new Target(pos.immutable(), 0.8f, 0.4f, 1.0f);
        if (crafters && block instanceof CrafterBlock) return new Target(pos.immutable(), 0.3f, 1.0f, 0.55f);
        return null;
    }

    private static void drawLine(PoseStack matrices, VertexConsumer lines, Vec3 from, Vec3 to, float r, float g, float b) {
        var pose = matrices.last();
        float dx = (float) (to.x - from.x);
        float dy = (float) (to.y - from.y);
        float dz = (float) (to.z - from.z);
        float length = (float) Math.sqrt(dx * dx + dy * dy + dz * dz);
        if (length < 0.001f) return;
        float nx = dx / length, ny = dy / length, nz = dz / length;
        lines.addVertex(pose, (float) from.x, (float) from.y, (float) from.z).setColor(r, g, b, 0.9f).setNormal(pose, nx, ny, nz);
        lines.addVertex(pose, (float) to.x, (float) to.y, (float) to.z).setColor(r, g, b, 0.9f).setNormal(pose, nx, ny, nz);
    }

    private record Target(BlockPos pos, float r, float g, float b) {}
}
