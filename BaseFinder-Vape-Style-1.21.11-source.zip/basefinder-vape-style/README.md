# BaseFinder — Vape-inspired Fabric client mod

A compact dark/purple module menu and client-side block locator for Minecraft Java **1.21.11**.

## Features
- `Y` toggles BaseFinder on/off.
- `Right Shift` opens the module menu.
- Chests/trapped chests, hoppers, dispensers/droppers, shulker boxes, and crafters.
- Coloured block outlines and optional tracers.
- Scan radius can be cycled from 16 to 64 blocks in the menu.
- Scans only blocks in chunks already loaded by your client; it does not reveal unloaded chunks.

Use only in single-player or multiplayer worlds/servers where this kind of client-side visualisation is allowed. Similar-looking GUI styling is original and is not affiliated with or copied from Vape Client.

## Build
Requires Java 21 and internet access for Gradle to download Minecraft/Fabric dependencies.

1. Install Gradle 9.2.1 or generate a Gradle wrapper in this folder.
2. Run `gradle build` from this folder.
3. The mod jar should appear under `build/libs/`.
4. Put the remapped mod jar in your Minecraft `mods` folder with Fabric Loader and Fabric API for 1.21.11.

## Important status
This environment did not have network access or Gradle installed, so the project has **not been compiled or tested here**. Treat it as source code, not a ready-to-install jar. If the current 1.21.11 mappings/API changed, a compile fix may be needed.
